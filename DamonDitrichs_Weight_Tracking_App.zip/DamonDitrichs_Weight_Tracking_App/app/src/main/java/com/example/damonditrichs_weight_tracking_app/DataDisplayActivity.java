package com.example.damonditrichs_weight_tracking_app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DataDisplayActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 1;
    private AppDatabase db;
    private WeightAdapter adapter;
    private List<Weight> weightList;
    private SharedPreferences preferences;
    private TextView goalWeightDisplay;
    private String userPhoneNumber = "+1 555-123-4567";
    private Button toggleSmsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "database-name")
                .fallbackToDestructiveMigration()
                .allowMainThreadQueries()
                .build();

        preferences = getSharedPreferences("app_prefs", MODE_PRIVATE);

        weightList = db.weightDao().getAllWeights();

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WeightAdapter(weightList, db);
        recyclerView.setAdapter(adapter);

        goalWeightDisplay = findViewById(R.id.goal_weight_display);
        updateGoalWeightDisplay();

        EditText bottomInput = findViewById(R.id.bottom_input);
        Button actionButton = findViewById(R.id.action_button);

        actionButton.setOnClickListener(v -> {
            String weightStr = bottomInput.getText().toString().trim();
            if (!weightStr.isEmpty()) {
                float weightValue = Float.parseFloat(weightStr);
                String currentDate = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault()).format(new Date());

                Weight weight = new Weight();
                weight.weight = weightValue;
                weight.date = currentDate;

                db.weightDao().insert(weight);
                weightList.add(weight);
                adapter.notifyItemInserted(weightList.size() - 1);
                bottomInput.setText("");

                checkAndSendSMS(weightValue);

                Toast.makeText(DataDisplayActivity.this, "Weight logged", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(DataDisplayActivity.this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            }
        });

        Button settingsButton = findViewById(R.id.settings_button);
        settingsButton.setOnClickListener(v -> showGoalWeightDialog());

        toggleSmsButton = findViewById(R.id.toggle_sms_button);
        toggleSmsButton.setOnClickListener(v -> showSmsPermissionDialog());

        updateSmsButtonState();
    }

    private void showSmsPermissionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_set_sms_permission, null);
        builder.setView(dialogView);

        RadioGroup smsPermissionGroup = dialogView.findViewById(R.id.sms_permission_group);
        RadioButton smsPermissionYes = dialogView.findViewById(R.id.sms_permission_yes);
        RadioButton smsPermissionNo = dialogView.findViewById(R.id.sms_permission_no);
        Button smsPermissionButton = dialogView.findViewById(R.id.sms_permission_button);

        AlertDialog dialog = builder.create();

        smsPermissionButton.setOnClickListener(v -> {
            int selectedId = smsPermissionGroup.getCheckedRadioButtonId();
            if (selectedId == R.id.sms_permission_yes) {
                requestSmsPermission();
            } else if (selectedId == R.id.sms_permission_no) {
                updateSmsButtonState();
            }
            dialog.dismiss();
        });

        dialog.show();
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            updateSmsButtonState();
        }
    }

    private void updateSmsButtonState() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            toggleSmsButton.setText("SMS Permission ON");
        } else {
            toggleSmsButton.setText("SMS Permission OFF");
        }
    }

    private void checkAndSendSMS(float weightValue) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            float goalWeight = preferences.getFloat("goal_weight", -1);
            if (goalWeight != -1 && weightValue <= goalWeight) {
                sendSMS(userPhoneNumber, "Congratulations you have hit your goal weight");
            }
        }
    }

    private void sendSMS(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }

    private void showGoalWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_set_goal_weight, null);
        builder.setView(dialogView);

        EditText goalInput = dialogView.findViewById(R.id.goal_input);
        Button goalButton = dialogView.findViewById(R.id.goal_button);

        AlertDialog dialog = builder.create();
        goalButton.setOnClickListener(v -> {
            String goalStr = goalInput.getText().toString().trim();
            if (!goalStr.isEmpty()) {
                float goalValue = Float.parseFloat(goalStr);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putFloat("goal_weight", goalValue);
                editor.apply();
                updateGoalWeightDisplay();
                Toast.makeText(DataDisplayActivity.this, "Goal weight set", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            } else {
                Toast.makeText(DataDisplayActivity.this, "Please enter a goal weight", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void updateGoalWeightDisplay() {
        float goalWeight = preferences.getFloat("goal_weight", -1);
        if (goalWeight != -1) {
            goalWeightDisplay.setText("Goal weight: " + goalWeight);
        } else {
            goalWeightDisplay.setText("Goal weight: Not set");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            updateSmsButtonState();
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
